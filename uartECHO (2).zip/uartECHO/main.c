#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* State definitions */
#define STATE_WAIT_O    0  // Waiting for 'O'
#define STATE_WAIT_N    1  // Waiting for 'N'
#define STATE_WAIT_F    2  // Waiting for 'F'
#define STATE_WAIT_SECOND_F 3  // Waiting for second 'F'

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char input;                  // Serial input (1 byte buffer)
    unsigned char state = STATE_WAIT_O;  // State (1 byte buffer)
    UART2_Handle uart;
    UART2_Params uartParams;
    size_t bytesRead = 0;
    size_t bytesWritten = 0;
    const char echoPrompt[] = "Type ON to turn on LED, OFF to turn it off:\r\n";

    /* Initialize GPIO */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Initialize UART2 */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL)
    {
        /* UART2_open() failed */
        while (1) {}
    }

    /* Turn on user LED to indicate successful initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    /* Write the echo prompt to UART */
    if (UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten) != UART2_STATUS_SUCCESS)
    {
        /* UART2_write() failed */
        while (1) {}
    }

    /* Main loop: Read input and update state machine */
    while (1)
    {
        bytesRead = 0;

        /* Read one character from UART */
        while (bytesRead == 0)
        {
            if (UART2_read(uart, &input, 1, &bytesRead) != UART2_STATUS_SUCCESS)
            {
                /* UART2_read() failed */
                while (1) {}
            }
        }

        /* Echo the character back */
        if (UART2_write(uart, &input, 1, &bytesWritten) != UART2_STATUS_SUCCESS)
        {
            /* UART2_write() failed */
            while (1) {}
        }

        /* State machine to process input */
        switch (state)
        {
            case STATE_WAIT_O:
                if (input == 'O')
                {
                    state = STATE_WAIT_N;
                }
                else if (input == 'F')
                {
                    state = STATE_WAIT_F;
                }
                break;

            case STATE_WAIT_N:
                if (input == 'N')
                {
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn LED on
                    state = STATE_WAIT_O;  // Reset to initial state
                }
                else
                {
                    state = STATE_WAIT_O;  // Invalid input, reset state
                }
                break;

            case STATE_WAIT_F:
                if (input == 'F')
                {
                    state = STATE_WAIT_SECOND_F;
                }
                else
                {
                    state = STATE_WAIT_O;  // Invalid input, reset state
                }
                break;

            case STATE_WAIT_SECOND_F:
                if (input == 'F')
                {
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Turn LED off
                    state = STATE_WAIT_O;  // Reset to initial state
                }
                else
                {
                    state = STATE_WAIT_O;  // Invalid input, reset state
                }
                break;

            default:
                state = STATE_WAIT_O;  // Callback to initial state
                break;
        }
    }
}
