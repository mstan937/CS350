/* ========================= Includes ========================= */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* ========================= Global Variables ========================= */

/* UART Global Variables */
UART_Handle uart;
char output[64];  // For UART display

/* I2C Global Variables */
I2C_Handle i2c;
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x00, "11X" },
    { 0x49, 0x00, "116" },
    { 0x41, 0x01, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

/* Timer Global Variables */
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

/* Application-Specific Global Variables */
int16_t currentTemp = 25;    // Current room temperature read from sensor
int16_t setPoint = 25;       // Desired set-point temperature
int secondsCount = 0;
int heatOn = 0;              // 0 = off, 1 = on

/* For button state checking */
uint8_t button0Prev = 1; // Assume not pressed initially
uint8_t button1Prev = 1; // Assume not pressed initially

/* ========================= Macros ========================= */
#define DISPLAY(x) UART_write(uart, output, x);

/* ========================= Function Prototypes ========================= */
void initUART(void);
void initI2C(void);
int16_t readTemp(void);
void initTimer(void);
void timerCallback(Timer_Handle myHandle, int_fast16_t status);

/* ========================= Driver Initialization Functions ========================= */

void initUART(void) {
    UART_Params uartParams;
    UART_init();
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;
    uart = UART_open(CONFIG_UART_0, &uartParams);
    if (uart == NULL) {
        while (1);
    }
}

void initI2C(void) {
    I2C_Params i2cParams;
    int8_t i, found = false;

    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));

    I2C_init();

    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        DISPLAY(snprintf(output, 64, "Failed\n\r"));
        while (1);
    }
    DISPLAY(snprintf(output, 64, "Passed\n\r"));

    // Determine which sensor is present
    i2cTransaction.writeBuf   = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf    = rxBuffer;
    i2cTransaction.readCount  = 0;

    for (i = 0; i < 3; i++) {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));
        if (I2C_transfer(i2c, &i2cTransaction)) {
            DISPLAY(snprintf(output, 64, "Found\n\r"));
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"));
    }

    if (found) {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress));
    } else {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"));
    }
}

int16_t readTemp(void) {
    int16_t temperature = 0;

    i2cTransaction.readCount  = 2;
    if (I2C_transfer(i2c, &i2cTransaction)) {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        /* Sign extend if necessary */
        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;
        }
        /* Convert to degrees C (TMP101: each bit = 0.0078125C) */
        temperature = (int16_t)(temperature * 0.0078125);
    } else {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r", i2cTransaction.status));
        DISPLAY(snprintf(output, 64, "Please power cycle your board.\n\r"));
    }

    return temperature;
}

void initTimer(void) {
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    // We want to schedule tasks at 200ms, 500ms, and 1s intervals.
    // Set the timer to 100ms ticks to easily handle multiples:
    // 200ms = 2 ticks, 500ms = 5 ticks, 1000ms = 10 ticks
    params.period = 100000; // 100ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        while (1) {}
    }
}

void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1; // Indicate to main thread that 100ms has passed
}

/* ========================= Main Task Scheduler Logic ========================= */

void *mainThread(void *arg0) {
    /* Initialize Drivers */
    GPIO_init();
    initUART();
    initI2C();
    initTimer();

    /* Configure the LED pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Configure the Button pins */
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_NOPULL); // Ensure correct config
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_NOPULL);

    /* Turn on LED at start (assuming heater on initially) */
    GPIO_write(CONFIG_GPIO_LED_0, 1);

    // Scheduler counters
    unsigned int tickCount = 0;

    while (1) {
        // Wait for the timer interrupt
        while (!TimerFlag);
        TimerFlag = 0;
        tickCount++;

        // Tasks:
        // Every 200ms (every 2 ticks): Check buttons
        if (tickCount % 2 == 0) {
            uint8_t button0Val = GPIO_read(CONFIG_GPIO_BUTTON_0);
            uint8_t button1Val = GPIO_read(CONFIG_GPIO_BUTTON_1);

            // If button0 is pressed (active low), increment setPoint by 1 every 200ms
            if (button0Val == 0) {
                setPoint++;
                if (setPoint > 99) setPoint = 99;
            }

            // If button1 is pressed (active low), decrement setPoint by 1 every 200ms
            if (button1Val == 0) {
                setPoint--;
                if (setPoint < 0) setPoint = 0;
            }

            button0Prev = button0Val;
            button1Prev = button1Val;
        }

        // Every 500ms (every 5 ticks): read temperature from sensor
        if (tickCount % 5 == 0) {
            currentTemp = readTemp();
        }

        // Every 1000ms (every 10 ticks): update LED state and output via UART
        if (tickCount % 10 == 0) {
            secondsCount++; // One second passed

            // Determine heater state based on currentTemp vs setPoint
            if (currentTemp > setPoint) {
                heatOn = 0;
            } else {
                heatOn = 1;
            }
            GPIO_write(CONFIG_GPIO_LED_0, heatOn);

            // Send output to UART: <%02d,%02d,%d,%04d>
            DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\r\n", currentTemp, setPoint, heatOn, secondsCount));
        }
    }

    return NULL;
}
